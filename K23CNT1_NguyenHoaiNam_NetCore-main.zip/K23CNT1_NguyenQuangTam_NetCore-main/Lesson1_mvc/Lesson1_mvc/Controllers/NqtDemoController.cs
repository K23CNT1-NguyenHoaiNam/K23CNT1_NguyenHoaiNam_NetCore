﻿using Microsoft.AspNetCore.Mvc;

namespace Lesson1_mvc.Controllers
{
    public class NqtDemoController : Controller
    {
        public IActionResult NqtIndex2()
        {
            return View();
        }
    }
}
